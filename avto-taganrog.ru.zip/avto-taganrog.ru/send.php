<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $name = htmlspecialchars($_POST['name']);
  $phone = htmlspecialchars($_POST['phone']);
  $quiz_result = htmlspecialchars($_POST['quiz_result']);

  $to = "info@avto-taganrog.ru";
  $subject = "Новая заявка с сайта";
  $message = "
    Имя: $name \n
    Телефон: $phone \n
    Ответы в квизе: $quiz_result
  ";
  $headers = "From: no-reply@avto-taganrog.ru\r\n";
  $headers .= "Content-type: text/plain; charset=utf-8\r\n";

  if (mail($to, $subject, $message, $headers)) {
    echo json_encode(['status' => 'success']);
  } else {
    echo json_encode(['status' => 'error', 'message' => 'Ошибка отправки']);
  }
}
?>
